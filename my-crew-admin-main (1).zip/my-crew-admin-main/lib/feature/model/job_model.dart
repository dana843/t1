import 'package:my_crew_admin/feature/model/company_model.dart';

class JobModel{

  JobModel({this.title, this.company, this.salaryPeriod, this.salaryRange, this.jobType, this.isSaved});

  String? id;
  String? title;
  String? salaryRange;
  String? salaryPeriod;
  CompanyModel? company;
  JobType? jobType;
  bool? isSaved;  


  static const String idKey = 'id';
  static const String titleKey = 'title';
  static const String salaryRangeKey = 'salary_range';
  static const String salaryPeriodKey = 'salary_period';
  static const String companyKey = 'company';
  static const String jobTypeKey = 'job_type';


  Map<String, dynamic> toJson({bool local = false, bool isUpdate = false}){
    return {
    idKey : id,
    titleKey : title,
    };
  }

  JobModel.fromJson(Map<String, dynamic> json, {bool local = false}){
    id = json[idKey];
    title = json[titleKey];
  }
}

enum JobType{
  partTime,
  fullTime,
}