import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew_admin/feature/core/theme/size/size_manager.dart';
import 'package:my_crew_admin/feature/model/job_model.dart';
import 'package:my_crew_admin/feature/view/app/home/home_screen/widgets/job_item.dart';
import 'package:my_crew_admin/feature/view/widgets/app_back_button.dart';
import 'package:my_crew_admin/utils/localization/string_keys.dart';

class CompanyPositionsScreen extends StatelessWidget {
  const CompanyPositionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(leading: const AppBackButton(), title: Text(StringKeys.openPositions.tr),),
      body: ListView.separated(
        padding: EdgeInsets.symmetric(horizontal: SizeManager.w12, vertical: SizeManager.h16),
        itemCount: 10,
        itemBuilder: (context, index) => JobItem(job: JobModel()),
        separatorBuilder: (context, index) => SizedBox(height: SizeManager.h8,),
      ),
    );
  }
}