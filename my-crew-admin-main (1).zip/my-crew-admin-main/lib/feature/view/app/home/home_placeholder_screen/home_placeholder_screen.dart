import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew_admin/feature/core/theme/color/color_manager.dart';
import 'package:my_crew_admin/feature/core/theme/size/size_manager.dart';
import 'package:my_crew_admin/feature/core/theme/text_theme/font_size_manager.dart';
import 'package:my_crew_admin/feature/view/app/home/home_placeholder_screen/widgets/rail_leading.dart';
import 'package:my_crew_admin/feature/view_model/home_view_model.dart';
import 'package:my_crew_admin/utils/localization/string_keys.dart';
import 'package:my_crew_admin/utils/utils/utils.dart';


class HomePlaceholderScreen extends StatelessWidget {
  const HomePlaceholderScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Utils.instance.screenUtil(context: context);
    return Scaffold(
      body: GetBuilder<HomeViewModel>(
        initState: (_){
          if (!Get.isRegistered<HomeViewModel>()) {
            Get.put(HomeViewModel());
          }
        },
        builder: (_) {
          return Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              NavigationRail(
                backgroundColor: Theme.of(context).backgroundColor,
                extended: _.isExtended,
                selectedIndex: _.selectedRailIndex,
                groupAlignment: -1,
                onDestinationSelected: (index) {
                  _.changeRailIndex(index: index);
                },
                indicatorColor: ColorManager.instance.colorPrimary,
                trailing: Visibility(
                  visible: !Utils.instance.isMobile(),
                  child: Padding(
                    padding: EdgeInsets.only(top: SizeManager.w32),
                    child: FloatingActionButton.small( onPressed: (){
                      _.changeExtensionStatus();
                    }, child: Icon(_.isExtended ? Icons.arrow_back_ios : Icons.arrow_forward_ios, color: Theme.of(context).textTheme.headline1?.color,)),
                  ),
                ),
                leading: RailLeading(isExtended: _.isExtended),
                destinations:  <NavigationRailDestination>[
                  railItem(context: context, label: StringKeys.home.tr, icon: Icons.home_rounded),
                  railItem(context: context, label: StringKeys.users.tr, icon: Icons.person),
                  railItem(context: context, label: StringKeys.companies.tr, icon: Icons.business_outlined),
                  railItem(context: context, label: StringKeys.sendNotification.tr, icon: Icons.notification_add),
                  railItem(context: context, label: StringKeys.settings.tr, icon: Icons.settings_suggest_rounded),
                ],
              ),
              const VerticalDivider(thickness: 2, width: 1),
              // This is the main content.
              Expanded(
                child: _.screens[_.selectedRailIndex]),
            ],
          );
        }
      ),
    );
  }

  NavigationRailDestination railItem({required String label, required IconData icon, required BuildContext context}){
    return NavigationRailDestination(label: Text(label, style: Theme.of(context).textTheme.headline5?.copyWith(fontWeight: FontWeight.w500, fontSize: FontSizeManager.fontSize14), textAlign: TextAlign.justify,), icon: Icon(icon, color: Theme.of(context).textTheme.headline1?.color,), selectedIcon: Icon(icon,color: ColorManager.instance.white),);
  }
}

