import 'package:flutter/material.dart';
import 'package:my_crew_admin/feature/core/theme/color/color_manager.dart';
import 'package:my_crew_admin/feature/core/theme/size/size_manager.dart';
import 'package:my_crew_admin/feature/view/app/widgets/app_image_network.dart';

class RailLeading extends StatelessWidget {
  const RailLeading({ this.isExtended = false,
    Key? key,
  }) : super(key: key);

  final bool isExtended;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Container(
          height: SizeManager.h44,
          width: SizeManager.w44,
          margin: EdgeInsetsDirectional.only(top: SizeManager.h20, bottom: SizeManager.h20),
          padding: EdgeInsets.symmetric(
              horizontal: SizeManager.w2, vertical: SizeManager.h2),
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(
              color: ColorManager.instance.colorPrimary,
              shape: BoxShape.circle),
          child: Container(
            padding: EdgeInsets.symmetric(
                horizontal: SizeManager.w2, vertical: SizeManager.h2),
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
                color: Theme.of(context).scaffoldBackgroundColor,
                shape: BoxShape.circle),
            child: Container(
              clipBehavior: Clip.antiAlias,
              decoration: BoxDecoration(
                  color: ColorManager.instance.colorPrimary,
                  shape: BoxShape.circle),
              child:  const AppImageNetwork(),
            ),)),
            if(isExtended)...[
            SizedBox(width: SizeManager.w12,),
            Text('My Crew Admin', style: Theme.of(context).textTheme.headline4?.copyWith(fontWeight: FontWeight.w500),),
            SizedBox(width: SizeManager.w20,),
            ]
      ],
    );
  }
}
