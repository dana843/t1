
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew_admin/feature/core/theme/color/color_manager.dart';
import 'package:my_crew_admin/feature/core/theme/size/size_manager.dart';
import 'package:my_crew_admin/feature/model/job_model.dart';
import 'package:my_crew_admin/utils/localization/string_keys.dart';
import 'package:my_crew_admin/utils/utils/utils.dart';

class JobItem extends StatelessWidget {
  const JobItem({
    Key? key, required this.job,
  }) : super(key: key);

  final JobModel job;

@override
  Widget build(BuildContext context) {
    return Material(
      borderRadius: BorderRadius.circular(SizeManager.r12),
        color: Theme.of(context).backgroundColor,
      child: InkWell(
        onTap: (){
        },
        borderRadius: BorderRadius.circular(SizeManager.r12),
      child: Container(
        padding: EdgeInsets.only(left: SizeManager.w16, right: SizeManager.w16, bottom: SizeManager.h16,),
        child: Column(
          children: [
            ListTile(
              title: Text('Senior back-end developer', style: Theme.of(context).textTheme.headline5?.copyWith(fontWeight: FontWeight.bold),),
              subtitle: Text('500-1.5K/monthly', style: Theme.of(context).textTheme.bodyText2?.copyWith(fontWeight: FontWeight.w500),),
              trailing: kIsWeb ? TextButton(
                  onPressed: () {
                  Utils.instance.showAlertDialog(title: StringKeys.deleteJob.tr, body: StringKeys.areYouSureYouWantToDeleteThisJob.tr, positiveButtonText: StringKeys.delete.tr, positiveButtonOnPressed: ()=> Get.back(), negativeButtonText: StringKeys.cancel.tr, negativeButtonOnPressed: ()=> Get.back(), isDanger: true);
                  },
                  style: TextButton.styleFrom(
                    foregroundColor: ColorManager.instance.error,
                    padding: EdgeInsets.symmetric(horizontal: SizeManager.w8,),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(SizeManager.r12))
                  ),
                  child: Text(StringKeys.delete.tr),
                  ) : IconButton(onPressed: (){
                    Utils.instance.showAlertDialog(title: StringKeys.deleteJob.tr, body: StringKeys.areYouSureYouWantToDeleteThisJob.tr, positiveButtonText: StringKeys.delete.tr, positiveButtonOnPressed: ()=> Get.back(), negativeButtonText: StringKeys.cancel.tr, negativeButtonOnPressed: ()=> Get.back(), isDanger: true);
                  }, icon: const Icon(Icons.delete), color: ColorManager.instance.error,),
              contentPadding: EdgeInsets.zero,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.access_time, size: SizeManager.r16, color: Theme.of(context).textTheme.bodyText1?.color,),
                    SizedBox(width: SizeManager.w4,),
                    Text('15/12/2022', style: Theme.of(context).textTheme.bodyText2?.copyWith(fontWeight: FontWeight.w500,),),
                  ],
                ),
                Text('Part-time', style: Theme.of(context).textTheme.bodyText2?.copyWith(fontWeight: FontWeight.w500,),),
                Row(
                  children: [
                    Text('Open', style: Theme.of(context).textTheme.bodyText2?.copyWith(fontWeight: FontWeight.bold, color: ColorManager.instance.success),),
                SizedBox(width: SizeManager.w8,)
                  ],
                ),
              ],
            )
          ],
        ),
      ),
    ));
  }
}

