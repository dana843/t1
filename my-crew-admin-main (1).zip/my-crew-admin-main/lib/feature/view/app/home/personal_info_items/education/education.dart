import 'package:flutter/material.dart';
import 'package:my_crew_admin/feature/core/theme/size/size_manager.dart';
import 'package:my_crew_admin/feature/view/app/home/personal_info_items/education/widgets/education_item.dart';


class Education extends StatelessWidget {
  const Education({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      shrinkWrap: true,
      padding: EdgeInsets.zero,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: 2,
      itemBuilder: (context, index) => const EducationItem(),
      separatorBuilder: (context, index) => SizedBox(height: SizeManager.h8,),
    );
  }
}