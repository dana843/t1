import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew_admin/feature/core/theme/size/size_manager.dart';
import 'package:my_crew_admin/feature/view/app/home/send_notification_screen/widgets/notification_target_bottom_sheet.dart';
import 'package:my_crew_admin/feature/view/widgets/app_text_form_filed.dart';
import 'package:my_crew_admin/utils/localization/string_keys.dart';

class SendNotificatonScreen extends StatelessWidget {
  const SendNotificatonScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(StringKeys.sendNotification.tr),),
      body: ListView(
        padding: EdgeInsets.symmetric(horizontal: SizeManager.w12, vertical: SizeManager.h12),
        children: [
          AppTextFormFiled(controller: TextEditingController() , label: StringKeys.notificationTitle ),
          SizedBox(height: SizeManager.h16,),
          AppTextFormFiled(controller: TextEditingController() , label: StringKeys.notificationBody ),
          SizedBox(height: SizeManager.h16,),
          AppTextFormFiled(controller: TextEditingController() , label: StringKeys.target, readOnly: true, onTap: () => Get.bottomSheet(const NotificationTargetBottomSheet(),
                                isScrollControlled: true),),
          SizedBox(height: SizeManager.h32,),
          ElevatedButton(onPressed: (){}, child: Text(StringKeys.send.tr))
        ],
      ),
    );
  }
}