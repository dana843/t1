
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew_admin/feature/core/theme/color/color_manager.dart';
import 'package:my_crew_admin/feature/core/theme/size/size_manager.dart';
import 'package:my_crew_admin/utils/localization/string_keys.dart';
import 'package:my_crew_admin/utils/utils/utils.dart';

class NotificationTargetBottomSheet extends StatelessWidget {
  const NotificationTargetBottomSheet({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Utils.instance.screenUtil(context: context);
    return  Container(
          padding: EdgeInsets.only(
            top: SizeManager.h8,
          ),
          decoration: BoxDecoration(
              color: Theme.of(context).scaffoldBackgroundColor,
              borderRadius:
              BorderRadius.vertical(top: Radius.circular(SizeManager.r24))),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
              width: SizeManager.w80,
              height: SizeManager.h4,
              decoration: BoxDecoration(
                  color: Theme.of(context).textTheme.bodyText1?.color,
                  borderRadius: BorderRadius.circular(SizeManager.r4)),
            ),
            SizedBox(
              height: SizeManager.h40,
              width: Get.width,
            ),
              ListView(shrinkWrap: true ,
                    children : [ 
                      NotificationTargetItem(label: StringKeys.users.tr, onTap: (){},),
                      NotificationTargetItem(label: StringKeys.companies.tr, onTap: (){},),
                      NotificationTargetItem(label: StringKeys.all.tr, onTap: (){},),
                      ]
                  ),
            Container(
              width: Get.width,
              height: SizeManager.h60,
              alignment: Alignment.center,
              color: ColorManager.instance.colorPrimary,
              child: Text(StringKeys.notificationTarget.tr,
                  style: Theme.of(context)
                      .textTheme
                      .headline5
                      ?.copyWith(fontWeight: FontWeight.w500, color: ColorManager.instance.textColorDark)),
            )
            ],
          ),
    );
  }
}

class NotificationTargetItem extends StatelessWidget {
  const NotificationTargetItem({
    Key? key, required this.label, required this.onTap,
  }) : super(key: key);

  final String label;
  final void Function() onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Theme.of(context).scaffoldBackgroundColor,
      child: InkWell(
          onTap: () {
            onTap;
            Get.back();
          },
          child: Padding(
            padding: EdgeInsets.symmetric(vertical: SizeManager.h20),
            child: Text(
              label,
              style: Theme.of(context)
                  .textTheme
                  .headline5
                  ?.copyWith(fontWeight: FontWeight.w500),
                  textAlign: TextAlign.center,
            ),
          )),
    );
  }
}
