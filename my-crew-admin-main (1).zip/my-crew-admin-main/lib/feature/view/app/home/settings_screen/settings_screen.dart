

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew_admin/feature/core/theme/size/size_manager.dart';
import 'package:my_crew_admin/feature/view/app/home/settings_screen/appearance_screen/appearance_screen.dart';
import 'package:my_crew_admin/feature/view/app/home/settings_screen/languages_screen/languages_screen.dart';
import 'package:my_crew_admin/feature/view/app/home/settings_screen/widgets/profile_setting_item.dart';
import 'package:my_crew_admin/feature/view/auth/login/login_screen.dart';
import 'package:my_crew_admin/utils/localization/string_keys.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(StringKeys.settings.tr),),
      body: ListView(
        padding: EdgeInsets.symmetric(horizontal: SizeManager.w12, vertical: SizeManager.h12),
        children: [
          ProfileSettingsItem(icon: Icons.mode_night, label: StringKeys.appearance.tr, onPressed: (){
            Get.to(()=> const AppearanceScreen());
          }),
          ProfileSettingsItem(icon: Icons.translate, label: StringKeys.language.tr, onPressed: (){
            Get.to(()=> const LanguagesScreen());
          }),
          ProfileSettingsItem(icon: Icons.logout, label: StringKeys.logout.tr, onPressed: (){
            Get.offAll(()=> const LoginScreen());
          }),
        ],
      ),
    );
  }
}