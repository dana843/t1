import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew_admin/feature/core/theme/color/color_manager.dart';
import 'package:my_crew_admin/feature/core/theme/size/size_manager.dart';
import 'package:my_crew_admin/feature/view/app/home/personal_info_items/widgets/profile_info_section.dart';
import 'package:my_crew_admin/feature/view/app/home/user_profile_screen/widgets/address/user_address.dart';
import 'package:my_crew_admin/feature/view/app/home/user_profile_screen/widgets/bio/user_bio.dart';
import 'package:my_crew_admin/feature/view/app/home/user_profile_screen/widgets/education/user_education.dart';
import 'package:my_crew_admin/feature/view/app/home/user_profile_screen/widgets/skills/user_skills.dart';
import 'package:my_crew_admin/feature/view/app/home/user_profile_screen/widgets/user_profile_image.dart';
import 'package:my_crew_admin/feature/view/widgets/app_back_button.dart';
import 'package:my_crew_admin/utils/localization/string_keys.dart';
import 'package:url_launcher/url_launcher_string.dart';

class UserProfileScreen extends StatelessWidget {
  const UserProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(leading: const AppBackButton(), title: const Text('User name'),),
      body: ListView(
        padding: EdgeInsets.symmetric(horizontal: SizeManager.w12, vertical: SizeManager.h20),
        children: [
          const UserProfileImage(),
          SizedBox(height: SizeManager.h16,),
          Text('User name', style: Theme.of(context).textTheme.headline4?.copyWith(fontWeight: FontWeight.w500), textAlign: TextAlign.center,),
          Align(
            alignment: Alignment.center,
            child: InkWell(
              onTap: (){},
              borderRadius: BorderRadius.circular(SizeManager.r8),
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: SizeManager.w8, vertical: SizeManager.h3),
                child: Text('user@gmail.com', style: Theme.of(context).textTheme.headline5?.copyWith(fontWeight: FontWeight.w500, color: ColorManager.instance.colorPrimary), textAlign: TextAlign.center,),
              ),
            ),
          ),
          SizedBox(height: SizeManager.h4,),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(onPressed: (){
                launchUrlString('mailto: anawajha@icloud.com');
              }, icon: const Icon(Icons.email_rounded), color: ColorManager.instance.colorPrimary,),
              SizedBox(width: SizeManager.w8,),
              IconButton(onPressed: (){
              }, icon: const Icon(Icons.message_rounded), color: ColorManager.instance.colorPrimary,),
              SizedBox(width: SizeManager.w8,),
              IconButton(onPressed: (){
                launchUrlString("tel://+972592686823");
              }, icon: const Icon(Icons.phone_rounded), color: ColorManager.instance.colorPrimary,),
            ],
          ),
          ProfileInfoSection(label: StringKeys.bio.tr, hasButton: false, content: const UserBio()),
          ProfileInfoSection(label: StringKeys.education.tr, hasButton: false, content: const UserEducation()),
          ProfileInfoSection(label: StringKeys.skills.tr, hasButton: false, content: const UserSkills()),
          ProfileInfoSection(label: StringKeys.address, hasButton: false, content: const UserAddress()),
        ],
      ),
    );
  }
}