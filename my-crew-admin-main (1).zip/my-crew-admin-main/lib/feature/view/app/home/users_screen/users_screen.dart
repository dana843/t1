import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew_admin/feature/core/theme/size/size_manager.dart';
import 'package:my_crew_admin/feature/view/app/home/users_screen/widgets/user_item.dart';
import 'package:my_crew_admin/utils/localization/string_keys.dart';

class UsersScreen extends StatelessWidget {
  const UsersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(StringKeys.users.tr),),
      body: ListView.separated(
        padding: EdgeInsets.symmetric(horizontal: SizeManager.w12, vertical: SizeManager.h12),
        itemCount: 3, itemBuilder: (context, index) => const UserItem(), separatorBuilder:(context, index) => SizedBox(height: SizeManager.h6),),
    );
  }
}