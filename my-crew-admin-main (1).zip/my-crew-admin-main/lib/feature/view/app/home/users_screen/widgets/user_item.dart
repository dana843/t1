

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew_admin/feature/core/theme/color/color_manager.dart';
import 'package:my_crew_admin/feature/core/theme/size/size_manager.dart';
import 'package:my_crew_admin/feature/core/theme/text_theme/font_size_manager.dart';
import 'package:my_crew_admin/feature/view/app/home/user_profile_screen/user_profile_screen.dart';
import 'package:my_crew_admin/feature/view/app/widgets/app_image_network.dart';
import 'package:my_crew_admin/utils/localization/string_keys.dart';
import 'package:my_crew_admin/utils/utils/utils.dart';

class UserItem extends StatelessWidget {
  const UserItem({super.key});

  @override
  Widget build(BuildContext context) {
    return Material(
          borderRadius: BorderRadius.circular(SizeManager.r12),
        color: Theme.of(context).backgroundColor,
      child: InkWell(
        onTap: ()=> Get.to(()=> const UserProfileScreen()),
          borderRadius: BorderRadius.circular(SizeManager.r12),
        child: Container(
          padding: EdgeInsets.only(left: SizeManager.w16, right: SizeManager.w16,),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(SizeManager.r12),
          ),
          child: Padding(
            padding: EdgeInsets.symmetric(vertical: SizeManager.h10),
            child: Row(
              children: [
                AppImageNetwork(width: SizeManager.w40, height: SizeManager.h40, radius: SizeManager.r6, clip: Clip.antiAlias,),
                SizedBox(width : SizeManager.w12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Text('User name', style: Theme.of(context).textTheme.headline5?.copyWith(fontWeight: FontWeight.bold),),
                     Text('User address', style: Theme.of(context).textTheme.bodyText2?.copyWith(fontWeight: FontWeight.w500, fontSize: FontSizeManager.fontSize14),),
                    ],
                  ),
                ),
                 Row(
                   mainAxisSize: MainAxisSize.min,
                   mainAxisAlignment: MainAxisAlignment.end,
                   children: [
                     if(!Utils.instance.isMobile())...[
                     IconButton(
                         onPressed: ()=> Get.to(()=> const UserProfileScreen()),
                         icon: const Icon(Icons.visibility), color: ColorManager.instance.colorPrimary,),
                     ],
                     IconButton(
                         onPressed: ()=> Utils.instance.showAlertDialog(title: StringKeys.deleteUser.tr, body: StringKeys.areYouSureYouWantToDeleteThisUser.tr, positiveButtonText: StringKeys.delete.tr, positiveButtonOnPressed: ()=> Get.back(), negativeButtonText: StringKeys.cancel.tr, negativeButtonOnPressed: ()=> Get.back(), isDanger: true),
                         icon: const Icon(Icons.delete), color: ColorManager.instance.error,),
                   ],
                 ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}