import 'package:flutter/material.dart';
import 'package:my_crew_admin/feature/view/auth/login/widgets/login_form.dart';
import 'package:my_crew_admin/utils/utils/utils.dart';


class LoginScreen extends StatelessWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Utils.instance.screenUtil(context: context);
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Stack(children: [
      Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        alignment: Alignment.center,
        ),
        const LoginForm()
      ],)
    );
  }
}