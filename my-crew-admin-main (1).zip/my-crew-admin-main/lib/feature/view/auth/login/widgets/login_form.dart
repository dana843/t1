import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew_admin/feature/core/theme/color/color_manager.dart';
import 'package:my_crew_admin/feature/core/theme/size/size_manager.dart';
import 'package:my_crew_admin/feature/view/widgets/app_text_form_filed.dart';
import 'package:my_crew_admin/feature/view_model/auth_view_model.dart';
import 'package:my_crew_admin/utils/localization/string_keys.dart';
import 'package:my_crew_admin/utils/utils/utils.dart';


class LoginForm extends StatelessWidget {
  const LoginForm({Key? key,}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Utils.instance.screenUtil(context: context);
    return GetBuilder<AuthViewModel>(initState: (_) {
      if (!Get.isRegistered()) {
        Get.put(AuthViewModel());
      } else {
        Get.find<AuthViewModel>();
      }
    }, builder: (_) {
      return Form(
        key: _.loginFormKey,
        child: ListView(
          padding: EdgeInsets.symmetric(
              horizontal: SizeManager.w20, vertical: SizeManager.h80),
          children: [
            SizedBox(
              height: SizeManager.h80,
            ),
                Text(
                  StringKeys.login.tr,
                  style: Theme.of(context).textTheme.headline1?.copyWith(
                      fontWeight: FontWeight.bold),
                ),
     
            SizedBox(
              height: SizeManager.h32,
            ),
            AppTextFormFiled(
              controller: _.tdLoginEmail,
              label: StringKeys.email.tr,
              validator: (e) => !GetUtils.isEmail(e.toString())
                  ? StringKeys.invalidEmail.tr
                  : null,
            ),
            SizedBox(
              height: SizeManager.h20,
            ),
            AppTextFormFiled(
              controller: _.tdLoginPassword,
              label: StringKeys.password.tr,
              obscureText: !_.passwordVisibility,
              suffixIcon: IconButton(
                  onPressed: () => _.changePasswordVisibilityState(),
                  icon: Icon(
                    !_.passwordVisibility
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined,
                    color: ColorManager.instance.colorPrimary,
                  )),
            ),
            SizedBox(
              height: SizeManager.h24,
            ),
            ElevatedButton(
                onPressed: () {
                  if (_.loginFormKey.currentState!.validate()) {
                    _.login();
                  }
                },
                child: Text(StringKeys.login.tr)),
            SizedBox(
              height: SizeManager.h32,
            ),
          ],
        ),
      );
    });
  }
}
