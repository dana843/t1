import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:my_crew_admin/feature/view/app/home/home_placeholder_screen/home_placeholder_screen.dart';
import 'package:my_crew_admin/utils/utils/utils.dart';


class AuthViewModel extends GetxController {
  
  // Login screen
  final TextEditingController tdLoginEmail = TextEditingController();
  final TextEditingController tdLoginPassword = TextEditingController();

  final GlobalKey<FormState> loginFormKey = GlobalKey<FormState>();

  bool passwordVisibility = false;

  void changePasswordVisibilityState() {
    passwordVisibility = !passwordVisibility;
    update();
    Future.delayed(const Duration(seconds: 2), () {
      passwordVisibility = false;
      update();
    });
  }


  void login() async {
    try {
      Utils.instance.showProgressDialog();
      Get.offAll(()=> const HomePlaceholderScreen());
        clearAll();
      Utils.instance.hideProgressDialog();
    } catch (e) {
      Utils.instance.hideProgressDialog();
      Utils.instance.snackError(body: e.toString());

    }
  }


  Future<void> saveUserData(
      {required String userId}) async {}


  Future<void> getUserData({required String userId}) async {}

  void clearAll() {
    tdLoginEmail.clear();
    tdLoginPassword.clear();
  }
}
