import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew_admin/feature/view/app/home/companies_screen/companies_screen.dart';
import 'package:my_crew_admin/feature/view/app/home/home_screen/home_screen.dart';
import 'package:my_crew_admin/feature/view/app/home/send_notification_screen/send_notification_screen.dart';
import 'package:my_crew_admin/feature/view/app/home/settings_screen/settings_screen.dart';
import 'package:my_crew_admin/feature/view/app/home/users_screen/users_screen.dart';


class HomeViewModel extends GetxController {


// Navigation rail
  int selectedRailIndex = 0;

  bool isExtended = false;

  void changeExtensionStatus(){
    isExtended = !isExtended;
    update();
  }

  void changeRailIndex({required int index}) {
    selectedRailIndex = index;
    update();
  }

  List<Widget> screens = const [
     HomeScreen(),
     UsersScreen(),
     CompaniesScreen(),
     SendNotificatonScreen(),
     SettingsScreen()
  ];
}
