import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew_admin/feature/view/auth/login/login_screen.dart';
import 'package:my_crew_admin/feature/view_model/home_view_model.dart';
import 'package:my_crew_admin/utils/shared/shared_prefs.dart';


class SettingsViewModel extends GetxController {

  void logout() async {
    // auth.signOut();
    await SharedPrefs.instance.clearUserPrefs();
    Get.offAll(()=> const LoginScreen());
    await Get.delete<HomeViewModel>(force: true);
    await Get.delete<SettingsViewModel>(force: true);
  }

    void changeTheme({required ThemeMode mode}){
    SharedPrefs.instance.setTheme(mode: mode);
    Get.changeThemeMode(mode);
    update();
  }
}